<?php if (!defined('BASEPATH')) exit ('No direct script access allowed');
	
	$data['jenis_tanah'] = array("TANAH SAWAH" => "Tanah Sawah", "TANAH DARAT" => "Tanah Darat", "TANAH BANGUNAN" => "Tanah Bangunan");
	
	$data['bukti_kepemilikan'] = array(
		"PETOK LAMA" => "Petok lama",
		"PETOK BARU" => "Petok baru",
		"SIT SEGEL" => "Sit segel",
		"AKTA" => "Akta",
		"COPY" => "Copy",
		"BUKU KRAWANGAN DESA" => "Buku Krawangan Desa",
		"LAINNYA" => "Lainnya"
		);
	
	$data['asal_tanah'] = array(
		"YAYASAN" => "Yayasan",
		"WARISAN" => "Warisan",
		"HIBAH" => "Hibah",
		"JUAL BELI" => "Jual Beli",
		"LAINNYA" => "Lainnya"
		);
