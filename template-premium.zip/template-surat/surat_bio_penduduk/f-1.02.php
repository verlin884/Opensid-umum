<?php

    defined('BASEPATH') || exit('No direct script access allowed');

    include(FCPATH . "/template-surat/lampiran/f-1.02/view.php");

?>
