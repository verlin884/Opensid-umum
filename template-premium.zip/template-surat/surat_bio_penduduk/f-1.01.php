<?php

    defined('BASEPATH') || exit('No direct script access allowed');

    include(FCPATH . "/template-surat/lampiran/f-1.01/view.php");

?>
