<?php

    defined('BASEPATH') || exit('No direct script access allowed');

    // include data F101
    include(FCPATH . "/template-surat/lampiran/f-1.01/data.php");

?>
